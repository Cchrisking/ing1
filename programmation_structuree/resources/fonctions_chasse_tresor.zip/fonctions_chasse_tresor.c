
//Afficher le menu
int menu() {
    int choix;
    printf("\n1. Jouer");
    printf("\n2. Regles du jeu");
    printf("\n3. Quitter\n");
    scanf("%d",&choix);
    return choix;
}
// Afficher des règles du jeu
void afficherRegles(){
    printf("\nUtilisez z/q/s/w pour deplacer le chasseur (@) et attraper les tresors (*)\n");
}

// Afficher le cadre de la zone de jeu
void afficherCadre() {
    gotoxy(0,0);
    text_color(LIGHTGRAY);
    for (int y = 0; y <= HAUTEUR+1; y++) {
        for (int x = 0; x <= LARGEUR+1; x++) {
            if (y == 0 || y == HAUTEUR+1) printf("#");
            else if (x == 0 || x == LARGEUR+1) printf("#");
            else printf(" ");
        }
        printf("\n");
    }
}
// Afficher un caractère à une position dans la console avec une couleur
void afficherObjet(char c, int x, int y, int couleur) {
    /* A COMPLETER */
}

// Déplacer le chasseur selon la touche appuyée
void deplacerChasseur(char touche, int *x, int *y) {
    /* A COMPLETER */
}

// Génèrer des coordonnées aléatoires pour le trésor
void genererTresor(int *x, int *y) {
    /* A COMPLETER */
}

//Vérifier si le chasseur a attrapé un tresor//
void attrapperTresor(/* A COMPLETER */) {
    /* A COMPLETER */
}

//Jouer une partie
void jouer(){
    //déclarations et initialisations des variables pour le joueur
    int xJoueur = LARGEUR / 2;
    int yJoueur = HAUTEUR / 2;
    int score=0;
    //variables pour le trésor
    int xTresor, yTresor;
    //variables pour la gestion du temps
    clock_t temps_debut;
    double temps_ecoule;
    //variables pour la saise utilisateur (choix de direction de déplacement)
    char touche='a';
    //génération d'un trésor
    genererTresor(&xTresor,&yTresor);
    //initialisation du temps
    temps_ecoule=0;
    temps_debut = clock();
    //Affichage du cadre
    afficherCadre();
    //boucle de jeu
    do{
        /* partie autonome : ce que fait le programme quoi qu'il arrive */
        //calcul du temps écoulé
        /*ACOMPLETER*/
        //affichages
        //affichage du temps écoulé et du score
        gotoxy(0, HAUTEUR+4);
        printf("Temps : %.1f s  ", temps_ecoule);
        gotoxy(0, HAUTEUR+3);
        printf("Score : %d  ", score);
        //Affichage du chasseur
        /*ACOMPLETER*/
        //Affichage du trésor
        /*ACOMPLETER*/

        /* partie évènementielle : ce que fait le programme si l'utilisateur appuie sur une touche */
        /*ACOMPLETER*/

        //Petite pause pour que ça n'aille pas trop vite
        Sleep(50);
    }while((/*ACOMPLETER*/);
    clrscr();//efface la console
    printf("\nFin du jeu. Score final = %d\n", score);
}

// ==== SOUS-PROGRAMME PRINCIPAL ====
int main() {
    int choix;
    // initialisation du générateur pseudo-aléatoire
    srand(time(NULL));
    //boucle de retour au menu à la fin d'une partie
    do{
        //gestion du menu
        choix=menu();
        switch(choix){
            case 1 : /*lancement d'une partie*/
                    hide_cursor();
                    clrscr();
                    jouer();
                    show_cursor();
                    break;
            case 2 : afficherRegles(); break;
        }
    }while(choix!=3);

    return 0;
}
